## How to start

1. Clone the project into your localsystem.

2. Go to the app.py file and change the DB credentails there accordingly your connections.

3. Install the required packages 

    ```
        pip install -r requirements.txt
    ```
4. Run the flask app.


```sh
$ git clone https://github.com/piyushkummaar/ROB-CASE2.git .
$ cd project 
$ pip install -r requirements.txt
$ python app.py
```

Open http://127.0.0.1:5000/ Fill the form and data store into target DB.